Blockly.Blocks.lp2i_ledRGB_WS2812B_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.lp2i_ledRGB_WS2812B_setPixelColor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.lp2i_ledRGB_WS2812B_setBrightness.getBlockType = function() {
	return Blockly.Types.NUMBER;
};