Blockly.Blocks.ds18b20_search1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.ds18b20_temp1.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
