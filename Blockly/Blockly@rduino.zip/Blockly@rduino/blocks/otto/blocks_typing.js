Blockly.Blocks.otto9_home.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_move.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_dance.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_do.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_gesture.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_sound.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_getdistance.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_getnoise.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_touchbutton.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.otto9_mouth.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_matrix.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.otto9_matrix_text.getBlockType = function() {
	return Blockly.Types.NUMBER;
};