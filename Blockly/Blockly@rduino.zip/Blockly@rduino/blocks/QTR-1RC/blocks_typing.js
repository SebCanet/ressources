//---------------------------------QTR-1RC.js-------------------------------------

Blockly.Blocks.QTR_1RC_calibration.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.QTR_1RC_attach.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.QTR_1RC_readLine.getBlockType = function() {
	return Blockly.Types.NUMBER;
};