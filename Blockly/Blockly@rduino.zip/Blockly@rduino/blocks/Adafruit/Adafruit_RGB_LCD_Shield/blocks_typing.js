Blockly.Blocks.Adafruit_RGB_LCD_Shield_read_button.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};