Blockly.Blocks.dcmotor_v1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
