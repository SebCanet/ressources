Blockly.Blocks.nrf24l01_init.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.nrf24l01_send.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.nrf24l01_get.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};