Blockly.Blocks.jeulin_appel_pieton_voie1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.jeulin_appel_pieton_voie2.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.jeulin_detection_magnetique_ils1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.jeulin_detection_infrarouge_bari1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.jeulin_detection_luminosite_ldr1.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.jeulin_feux_voie1_led1red.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feux_voie1_led1yellow.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feux_voie1_led1green.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feux_voie2_led1red.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feux_voie2_led1yellow.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feux_voie2_led1green.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feu_pieton_led1red.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_feu_pieton_led1green.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jeulin_alarme_pieton_buzzer1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};