Blockly.Blocks.virtuino_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.virtuino_read_state_dv.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};