Blockly.Blocks.stepper_config.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.stepper_step.getBlockType = function() {
	return Blockly.Types.NUMBER;
};