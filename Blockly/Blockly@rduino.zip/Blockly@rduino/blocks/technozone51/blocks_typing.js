Blockly.Blocks.technozone_lcdinit.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_lcdspecial.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_lcdclear.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_lcdwrite.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_lcdspecial.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_lcdclear.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_led1red.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_led1green.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_led1yellow.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_relay1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_buzzer1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_buzzer_tone.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_irsend.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_sonar1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_servo1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_read_servo1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_btn1white.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_btn.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_bt_available.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_bt_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_speech_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_ihm_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_available.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ihm_change.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ihm_inter_read.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ihm_btn_read.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ihm_potar_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_bt_read.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.technozone_robot_bt_write.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.technozone_robot_irleft.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ircenter.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_irright.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ligleft.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_robot_ligright.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_btn1black.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_btn1green.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_btn1red.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_switch1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_ils1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_proxi1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_bari1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_lig1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_cmouv1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_potar1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_ctn1.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.technozone_ldr1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_mot2.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_pap1cc.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_led_def.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_btn_def.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_speech_say.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_inter_def.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_led_on.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_inter_on.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_potar_def.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_gauge_def.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_ihm_gauge_write.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_pap1relatif.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_move.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_turn.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_robot_stop.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_pap1init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_pap1busy.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_mot1easybot1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_mot1easycon1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_telec2.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_telecsetup.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_telec1.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.technozone_telecinit.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.technozone_telecflush.getBlockType = function() {
	return Blockly.Types.NUMBER;
};