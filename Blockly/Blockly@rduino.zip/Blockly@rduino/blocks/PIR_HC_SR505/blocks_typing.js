Blockly.Blocks.SR505_detect.getBlockType = function () {
	return Blockly.Types.NUMBER;
};