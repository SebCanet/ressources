Blockly.Blocks.robuno_led_rouge.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.robuno_led_blanche.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.robuno_buzzer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.robuno_servomoteur_gauche.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.robuno_servomoteur_droite.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.robuno_capteur_collision_gauche.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.robuno_capteur_collision_droite.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.robuno_ldr_gauche.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.robuno_ldr_droite.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.robuno_moteurs_CC.getBlockType = function() {
	return Blockly.Types.NUMBER;
};