Blockly.Blocks.ADXL362_XValue.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.ADXL362_YValue.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.ADXL362_ZValue.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.ADXL362_TempValue.getBlockType = function () {
	return Blockly.Types.NUMBER;
};