Blockly.Blocks.SPI_init.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.SPI_send.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.SPI_receive.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};