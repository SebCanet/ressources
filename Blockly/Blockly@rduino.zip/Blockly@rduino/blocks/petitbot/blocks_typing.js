Blockly.Blocks.petitbot_hcsr04.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_analog_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_move_left.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_move_right.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_move_1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_move_2.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_move_3.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_digital_write_led1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.petitbot_digital_write_led2.getBlockType = function() {
	return Blockly.Types.NUMBER;
};