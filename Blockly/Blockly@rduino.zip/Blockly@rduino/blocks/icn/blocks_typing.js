Blockly.Blocks.hcsr04.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.ds18b20_search.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.ds18b20_temp.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.servomotor_attached.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.servomotor_attach.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.servomotor_detach.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.servomotor_angle.getBlockType = function() {
	return Blockly.Types.NUMBER;
};