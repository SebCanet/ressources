//---------------------------------IR.js-------------------------------------
Blockly.Blocks.IR_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.IR_test_LED.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.IR_test_monitor.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.IR_next_value.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.IR_detection.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.IR_reception_code.getBlockType = function() {
	return Blockly.Types.LARGE_NUMBER;
};