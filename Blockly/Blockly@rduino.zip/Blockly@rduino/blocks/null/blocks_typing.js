//---------------------------------null.js-------------------------------------

Blockly.Blocks.null_start.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_in.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_out.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_in_out.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_end.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_loop.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_loop_inside.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_loop_inside_in.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_loop_do_inside.getBlockType = function() {
	return Blockly.Types.UNDEF;
};
Blockly.Blocks.null_loop_do_inside_in.getBlockType = function() {
	return Blockly.Types.UNDEF;
};