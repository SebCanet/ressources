Blockly.Blocks.tsl2561_init.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.tsl2561_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};