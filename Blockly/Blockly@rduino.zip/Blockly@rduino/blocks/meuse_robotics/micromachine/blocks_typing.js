//---------------------------------IR.js-------------------------------------
Blockly.Blocks.mIR_receiver.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mIR_get_code.getBlockType = function() {
	return Blockly.Types.LARGE_NUMBER;
};