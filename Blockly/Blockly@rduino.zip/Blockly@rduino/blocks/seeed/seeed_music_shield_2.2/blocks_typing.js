Blockly.Blocks.seeed_music_shield_addtolist.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playlist.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playmode.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playName.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playAll.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_disableKeys.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_setVolume.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_setVolumeFunction.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_setDigitalFunction.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playNextSong.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playPreviousSong.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playPause.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playResume.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_playStop.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_volumeUp.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_volumeDown.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.seeed_music_shield_buttonVolumeUp.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.seeed_music_shield_buttonVolumeDown.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.seeed_music_shield_buttonPlayStop.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.seeed_music_shield_buttonNextSong.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.seeed_music_shield_buttonPreviousSong.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};