Blockly.Blocks.grove_led.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_button.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_rotary_angle.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_ldr.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_tilt_switch.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_piezo_buzzer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_relay.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_temporature_sensor.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.grove_serial_lcd_print.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_serial_lcd_power.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_serial_lcd_effect.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_sound_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_pir_motion_sensor.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_line_finder.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_ultrasonic_ranger.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_motor_shield.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_thumb_joystick.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_rgb_led.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_bluetooth_slave.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_dht_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_mini_driver_error.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_bluetooth_slave_AT.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_FIN_COURSE.getBlockType = function() {
   return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.grove_EMETTEUR_IR.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.grove_RECEPTEUR_IR.getBlockType = function() {
   return Blockly.Types.BOOLEAN;
};