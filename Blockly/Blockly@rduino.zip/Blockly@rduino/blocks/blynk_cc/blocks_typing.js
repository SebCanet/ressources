//***********************************************************
//                      www.blynk.cc by Mr Leroy
//***********************************************************

//****************************blynk_cc.js********************

Blockly.Blocks.blynk_cc_uno_cnx_usb.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_connect.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_ethernet_begin.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_write.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_virtual_write.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_email.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_notify.getBlockType = function() {
   return Blockly.Types.NUMBER;
};
Blockly.Blocks.blynk_cc_tweet.getBlockType = function() {
   return Blockly.Types.NUMBER;
};