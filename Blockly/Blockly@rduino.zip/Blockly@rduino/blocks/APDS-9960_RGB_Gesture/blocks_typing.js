Blockly.Blocks.APDS9960_ColorSensor_init.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.APDS9960_ColorSensor_test.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.APDS9960_ColorSensor_ambient.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.APDS9960_ColorSensor_red.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.APDS9960_ColorSensor_green.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.APDS9960_ColorSensor_blue.getBlockType = function() {
	return Blockly.Types.NUMBER;
};