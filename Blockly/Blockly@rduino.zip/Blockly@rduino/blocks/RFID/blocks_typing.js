Blockly.Blocks.RFID_module.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.RFID_detection.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.RFID_reception_cle.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.RFID_lecture_cle.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.RFID_fermeture.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.RFID_valeur_cle.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.RFID_code_acces.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.RFID_acces_autorise.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};