Blockly.Blocks.flycam_switch.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.flycam_record.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.flycam_stop.getBlockType = function() {
	return Blockly.Types.NUMBER;
};