Blockly.Blocks.LCD_Keypad_Shield_DFR_09.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.LCD_Keypad_Shield_DFR_09_Buttons.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};