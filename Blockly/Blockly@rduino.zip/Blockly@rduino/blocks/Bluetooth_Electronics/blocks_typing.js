Blockly.Blocks.BT_ELEC_Init.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.BT_ELEC_LED_brightness.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.BT_ELEC_RC_car.getBlockType = function () {
	return Blockly.Types.NUMBER;
};