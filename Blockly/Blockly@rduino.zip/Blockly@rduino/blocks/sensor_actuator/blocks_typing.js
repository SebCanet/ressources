Blockly.Blocks.SENSOR_ACTUATOR_inout_buildin_led.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_blink.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_digital_write.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_bargraphe.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_matrice8x8_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_matrice8x8_symbole.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_matrice8x8.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_matrice8x8_aff.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_matrice_nombre_0_30.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lcd.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lcd_i2c.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_LCD_Keypad_Shield_DFR_09.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_LCD_Keypad_Shield_DFR_09_lc.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_LCD_Keypad_Shield_DFR_09_RAZ.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_moteur_action.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_moteur_stop.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_moteur3v.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_moteur_dc.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_dagu_rs027.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_volume.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_next.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_prev.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_pause.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_lp2i_mp3_play.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_tone.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_notone.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_inout_bp.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.SENSOR_ACTUATOR_lm35.getBlockType = function() {
	return Blockly.Types.LARGE_NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_ultrason_distance.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_potentiometre.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_dht11.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_suiveur_ligne.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.SENSOR_ACTUATOR_light_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.SENSOR_ACTUATOR_bluetooth_b.getBlockType = function() {
	return Blockly.Types.NUMBER;
};