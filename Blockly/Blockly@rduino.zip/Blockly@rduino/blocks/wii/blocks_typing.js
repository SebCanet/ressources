Blockly.Blocks.wiichuck_joy.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.wiichuck_accel.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.wiichuck_button.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.wiichuck_update.getBlockType = function() {
	return Blockly.Types.NUMBER;
};