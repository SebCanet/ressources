Blockly.Blocks.servo_attach.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.servo_move.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.servo_read_degrees.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.servo_attached.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.servo_detach.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.servo_detach.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.servo_rot_continue.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.servo_rot_continue.getBlockType = function() {
	return Blockly.Types.NUMBER;
};