Blockly.Blocks.jfblocks_decode.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jfblocks_action.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jfblocks_tx.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.jfblocks_last_value.getBlockType = function() {
	return Blockly.Types.NUMBER;
};