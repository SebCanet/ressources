Blockly.Blocks.bq_led.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.bq_buzzer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.bq_ultrason.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.bq_servo.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.bq_bouton_poussoir.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.bq_capteur_de_ligne.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.bq_potentiometre.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.bq_luminosite.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.bq_servo_rotation_continue.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.bq_bluetooth_slave.getBlockType = function() {
	return Blockly.Types.TEXT;
};