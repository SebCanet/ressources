Blockly.Blocks.capacitiveSensor_init.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.capacitiveSensor_check.getBlockType = function () {
	return Blockly.Types.LARGE_NUMBER;
};