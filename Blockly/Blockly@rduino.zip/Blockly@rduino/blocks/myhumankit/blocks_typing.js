Blockly.Blocks.mhk_ultrason.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mhk_capteur_myoware.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mhk_moteur_vibreur.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mhk_servo_moteur.getBlockType = function() {
	return Blockly.Types.NUMBER;
};