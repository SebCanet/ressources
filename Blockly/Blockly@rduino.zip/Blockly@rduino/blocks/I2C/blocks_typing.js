Blockly.Blocks.I2C_init.getBlockType = function () {
	return Blockly.Types.NULL;
};
Blockly.Blocks.I2C_start.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.I2C_restart.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.I2C_stop.getBlockType = function () { 
	return Blockly.Types.NULL;
};
Blockly.Blocks.I2C_write.getBlockType = function () { 
	//return Blockly.Types.BOOLEAN;
	return Blockly.Types.NULL;
};
Blockly.Blocks.I2C_read.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.I2C_scan.getBlockType = function () {
	return Blockly.Types.NULL;
};

Blockly.Blocks.I2C_available_HW.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.I2C_data_HW.getBlockType = function () { 
	return Blockly.Types.NUMBER;
};
