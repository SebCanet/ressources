Blockly.Blocks.mbot_left_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_left_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_right_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_right_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_rgb_onboard.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_buzzer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_ultrasonic_ranger.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_IR_receiver.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.mbot_line_finder.getBlockType = function() {
	return Blockly.Types.NUMBER;
};