Blockly.Blocks.MRduino2_init.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_forward.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_forward_mm.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_stop.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_back.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_back_mm.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.MRduino2_motorRight.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_motorLeft.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_turnLeft.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.MRduino2_turnLeft_degree.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.MRduino2_turnRight_degree.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_turnRight.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.MRduino2_proxSensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.MRduino2_ledRight.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.MRduino2_ledLeft.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.MRduino2_battery.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
