Blockly.Blocks.dfrobot_ISD1820_record.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.dfrobot_ISD1820_play.getBlockType = function() {
	return Blockly.Types.NUMBER;
};