Blockly.Blocks.romeo_switch.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.romeo_forward.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_backward.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_turn_left.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_turn_right.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_mot_M1.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_mot_M2.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_M1_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_M1_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_M2_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_M2_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};