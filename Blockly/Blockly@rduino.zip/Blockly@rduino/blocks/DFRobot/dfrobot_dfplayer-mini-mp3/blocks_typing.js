Blockly.Blocks.lp2i_mp3_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};