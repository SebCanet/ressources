Blockly.Blocks.romeo_ble_switch.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.romeo_ble_M1_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_ble_M1_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_ble_M2_sens.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.romeo_ble_M2_PWM.getBlockType = function() {
	return Blockly.Types.NUMBER;
};