Blockly.Blocks.autoduino_button.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.autoduino_rotary_angle.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_rotary_push.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_potentiometer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_dht_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_temperature_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_moisture_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_tilt_switch.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_ils_switch.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_pir_motion_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_ultrasonic_ranger.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.autoduino_LDR_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_line_finder.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.autoduino_ir_switch.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_digital_temperature_sensor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_rc.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_ir_code_detection.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_edge_detection.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.autoduino_lcdinit.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_lcdspecial.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_lcdclear.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_lcdwrite.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.autoduino_lcdprint.getBlockType = function() {
	return Blockly.Types.NUMBER;
};