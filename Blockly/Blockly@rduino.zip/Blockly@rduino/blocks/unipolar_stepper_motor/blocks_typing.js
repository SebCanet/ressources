Blockly.Blocks.unipolar_stepper_motor_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.unipolar_stepper_motor_steps.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.unipolar_stepper_motor_turns.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.unipolar_stepper_motor_speed_block.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
