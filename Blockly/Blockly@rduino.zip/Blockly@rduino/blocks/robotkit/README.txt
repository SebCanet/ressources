# Blockly for RobotKit
Blockly version built for RobotKit's cirriculum by Fablab Saigon & Fablab Thao Dien
https://fablabsaigon.org/

Drop me an email at hello@fablabsaigon.org for any question 