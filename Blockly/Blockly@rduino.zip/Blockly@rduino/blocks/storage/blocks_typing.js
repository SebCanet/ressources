Blockly.Blocks.storage_sd_write.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.storage_eeprom_write_long.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.storage_eeprom_read_long.getBlockType = function() {
	return Blockly.Types.LARGE_NUMBER;
};
Blockly.Blocks.storage_eeprom_write_byte.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.storage_eeprom_read_byte.getBlockType = function() {
	return Blockly.Types.NUMBER;
};