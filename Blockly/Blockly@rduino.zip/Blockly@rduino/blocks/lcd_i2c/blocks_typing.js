Blockly.Blocks.lcd_i2c_lcdinit.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.lcd_i2c_lcdclear.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.lcd_i2c_lcdwrite.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.lcd_i2c_lcdscan.getBlockType = function () {
	return Blockly.Types.NULL;
};