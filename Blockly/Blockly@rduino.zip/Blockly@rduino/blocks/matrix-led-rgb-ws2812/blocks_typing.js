Blockly.Blocks.MatrixLED_WS2812B_init.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.MatrixLED_WS2812B_setPixelColor.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.MatrixLED_WS2812B_setBrightness.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.MatrixLED_WS2812B_CLEAN.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.MatrixLED_WS2812B_draw.getBlockType = function() {
	return Blockly.Types.NUMBER;
};