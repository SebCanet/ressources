Blockly.Blocks.lp2i_u8g_print.getBlockType = function() {
	return Blockly.Types.NUMBER;
};