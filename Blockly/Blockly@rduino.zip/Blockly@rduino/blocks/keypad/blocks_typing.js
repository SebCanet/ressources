Blockly.Blocks.keypad_touche_appuyee.getBlockType = function () {
	return Blockly.Types.TEXT;
};