Blockly.Blocks.Sharp_IR_attach.getBlockType = function () {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.Sharp_IR_read.getBlockType = function () {
	return Blockly.Types.NUMBER;
};