Blockly.Blocks.drone_ESC_pwm.getBlockType = function () {
	return Blockly.Types.NUMBER;
};