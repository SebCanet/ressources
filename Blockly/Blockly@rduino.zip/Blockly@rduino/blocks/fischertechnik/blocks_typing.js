Blockly.Blocks.fischertechnik_feu_rouge.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_feu_orange.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_feu_vert.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_barriere_lumineuse.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_buzzer.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.fischertechnik_BP_capteur_de_presence.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_capteur_magnetique.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.fischertechnik_capteur_de_lumiere.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.fischertechnik_moteurs_CC.getBlockType = function() {
	return Blockly.Types.NUMBER;
};