//---------------------------------zumo_motors.js-------------------------------------

Blockly.Blocks.zumo_motors_FN.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FNs.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FR.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FRs.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FL.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FLs.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FBs.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FB.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.zumo_motors_FUs.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
//---------------------------------zumo_sensors.js-------------------------------------

Blockly.Blocks.Zumo_setup_button_wait_il.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.Zumo_setup_button_wait_iph.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.Zumo_wait_button_push.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.Zumo_play_notes_z.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.Zumo_line_follower.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.Zumo_SensorCalibration.getBlockType = function() {
	return Blockly.Types.NULL;
};