Blockly.Blocks.EsusBoard_init.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_motor1.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_motor2.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_analog.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.EsusBoard_WifiConfig.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_WifiConfigIP.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_WifiConfigAP.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_ReadStream.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.EsusBoard_dataWifiAvailable.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.EsusBoard_WifiContain.getBlockType = function() {
	return Blockly.Types.TEXT;
};
Blockly.Blocks.EsusBoard_SendStream.getBlockType = function() {
	return Blockly.Types.NULL;
};
Blockly.Blocks.EsusBoard_SendFloatStream.getBlockType = function() {
	return Blockly.Types.NULL;
};