Blockly.Blocks.esp8266_init.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.esp8266_send.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_send_html.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_wait_server.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_wait_client.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_request_indexof.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_create_item.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};
Blockly.Blocks.esp8266_create_container.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};


