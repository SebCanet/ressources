Blockly.Blocks.HX711_init.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.HX711_read.getBlockType = function() {
	return Blockly.Types.DECIMAL;
};