Blockly.Blocks.multifunction_buildin_led.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_digital_read.getBlockType = function() {
	return Blockly.Types.BOOLEAN;
};
Blockly.Blocks.multifunction_pot_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_analog_read.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_tone.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_notone.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_segment.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_segment_number.getBlockType = function() {
	return Blockly.Types.NUMBER;
};
Blockly.Blocks.multifunction_PWM_write.getBlockType = function() {
	return Blockly.Types.NUMBER;
};