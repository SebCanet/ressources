Blockly.Blocks.anemometre_vitesse_rotation.getBlockType = function () {
	return Blockly.Types.NUMBER;
};


Blockly.Blocks.anemometre_vitesse_ventms.getBlockType = function () {
	return Blockly.Types.NUMBER;
};


Blockly.Blocks.anemometre_vitesse_ventkmh.getBlockType = function () {
	return Blockly.Types.NUMBER;
};


Blockly.Blocks.anemometre_vitesse_ventnoeud.getBlockType = function () {
	return Blockly.Types.NUMBER;
};


Blockly.Blocks.anemometre_force_Beaufort.getBlockType = function () {
	return Blockly.Types.NUMBER;
};