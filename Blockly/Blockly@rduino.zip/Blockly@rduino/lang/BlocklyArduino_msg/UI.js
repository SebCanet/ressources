var BlocklyArduinoMSG = {
  span_version: "<i>version 13-05-2020 - v3.2.5</i>",
};
