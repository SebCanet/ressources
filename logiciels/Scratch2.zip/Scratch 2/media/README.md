# scratch-media-lib-assets
## Media library assets for Scratch

## To Sync Assets
```bash
rm [0-9a-f][0-9a-f]*
python download-sprite-media.py
```
