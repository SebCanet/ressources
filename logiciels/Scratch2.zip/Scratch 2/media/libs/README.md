# scratch-media-libs
Contains the media library files for sprites, backdrops, costumes, and sounds. Run the Python script to re-generate the costume library from the sprite library.
