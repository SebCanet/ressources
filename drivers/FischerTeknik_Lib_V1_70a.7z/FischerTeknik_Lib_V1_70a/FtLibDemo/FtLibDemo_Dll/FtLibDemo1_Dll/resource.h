//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FtLibDemo1.rc
//
#define ID_CLOCK_TIMER                  101
#define IDD_FTLIBDEMO1_DIALOG           102
#define ID_TICK_TIMER                   102
#define IDR_MAINFRAME                   128
#define IDC_O08                         1001
#define IDC_I08                         1002
#define IDC_O07                         1003
#define IDC_I07                         1004
#define IDC_O06                         1005
#define IDC_I06                         1006
#define IDC_O05                         1007
#define IDC_I05                         1008
#define IDC_O04                         1009
#define IDC_I04                         1010
#define IDC_O03                         1011
#define IDC_I03                         1012
#define IDC_O02                         1013
#define IDC_I02                         1014
#define IDC_O01                         1015
#define IDC_I01                         1016
#define IDC_OWert                       1017
#define IDC_IWert                       1018
#define IDC_STATIC_Time                 1019
#define IDC_OWertHex                    1020
#define IDC_IWertHex                    1021
#define IDC_SB_O01                      1022
#define IDC_SB_O01Wert                  1023
#define IDC_SL_A01Wert                  1027
#define IDC_SL_A02Wert                  1028
#define IDC_SL_A01                      1029
#define IDC_SL_A02                      1030
#define IDC_SL_A0X                      1031
#define IDC_SL_A0XWert                  1032
#define IDC_SL_A0Y                      1033
#define IDC_RA_USB                      1034
#define IDC_RA_SERC1                    1035
#define IDC_EDIT1                       1037
#define IDC_SL_A0YWert                  1038
#define IDC_SL_A0Z                      1039
#define IDC_SL_A0ZWert                  1040
#define IDC_SL_Vers                     1041
#define IDC_SL_VersWert                 1042
#define IDC_SL_DS1                      1044
#define IDC_SL_DS1Wert                  1045
#define IDC_SB_O02                      1046
#define IDC_SB_O02Wert                  1047
#define IDC_SL_DS2                      1048
#define IDC_SL_DS2Wert                  1049
#define IDC_SB_O03                      1050
#define IDC_SB_O03Wert                  1051
#define IDC_SB_O04                      1052
#define IDC_SB_O04Wert                  1053
#define IDC_SB_O05                      1054
#define IDC_SB_O05Wert                  1055
#define IDC_SB_O06                      1056
#define IDC_SB_O06Wert                  1057
#define IDC_SB_O07                      1058
#define IDC_SB_O07Wert                  1059
#define IDC_SB_O08                      1060
#define IDC_SB_O08Wert                  1061
#define IDC_RA_SERC2                    1068
#define IDC_RA_SERC3                    1071
#define IDC_RA_SERC4                    1074
#define IDC_Online                      1078
#define IDC_SL_VersVolt                 1079
#define IDC_ST_IF_Firmware              1081
#define IDC_SL_A01Volt                  1082
#define IDC_SL_A02Volt                  1083
#define IDC_SL_A0ZVolt                  1084
#define IDC_RA_OFF                      1085
#define IDC_ST_IF_TYP                   1086
#define IDC_ST_IF_AKT_SN                1104
#define IDC_BUTTON_EXIT                 1105
#define IDC_BUTTON_SCANUSB              1110
#define IDC_LIST_USB                    1113
#define IDC_STATIC_USB_DEV              1117
#define IDC_ST_LIB_VER                  1118
#define IDC_BUTTON_STOP                 1123
#define IDC_BUTTON_START                1137
#define IDC_RAB_IIF                     1147
#define IDC_RAB_RIF                     1148
#define IDC_RAB_IIF_EXTENSION           1149
#define IDC_STATIC_IF_RAHMEN            1150
#define IDC_RADIO_DS_DS                 1187
#define IDC_RAB_DS_DS                   1187
#define IDC_RADIO_DS_VOLT               1188
#define IDC_RAB_DS_VOLT                 1188
#define IDC_EDIT_DS_TOL1                1189
#define IDC_EDIT_DS_TOL2                1190
#define IDC_EDIT_DS_SCHWELLE1           1191
#define IDC_EDIT_DS_SCHWELLE2           1192
#define IDC_EDIT_DS_REP1                1193
#define IDC_EDIT_DS_REP2                1194
#define IDC_STATIC_DS_TOL               1197
#define IDC_STATIC_DS_REP               1198
#define IDC_STATIC_DS_SCHWELL           1199
#define IDC_BUTTON_LL_TEST              1274
#define IDC_STATIC_DIAG_VER             1300

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
